/**
 * jQuery bootbox Custom
 * 
 * Author Joe
 */
bootbox.setDefaults({locale : "zh_CN"});