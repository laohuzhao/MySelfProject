/**
 * jQuery gritter custom
 * 
 * Author Joe
 */
$.gritter.options = {
	position: '',
	class_name: 'gritter-center gritter-light', // could be set to 'gritter-light' to use white notifications
	fade_in_speed: 'medium', // how fast notifications fade in
	fade_out_speed: 1000, // how fast the notices fade out
	time: 2000
}