
package com.gupaoedu.pay.biz.abs;

/**
 * 验证器基类
 * 
 */
public abstract class BaseValidator implements Validator {
    
}
